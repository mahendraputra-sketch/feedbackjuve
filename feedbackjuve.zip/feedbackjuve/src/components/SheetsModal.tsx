import React, { useState } from 'react';
import {
  X,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  PlusCircle,
  RefreshCw,
  FolderOpen,
  Info,
} from 'lucide-react';
import { User } from 'firebase/auth';
import { SheetsConfig } from '../types/feedback';
import { createJuveSpreadsheet, verifySpreadsheet } from '../lib/sheets';

interface SheetsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  accessToken: string | null;
  sheetsConfig: SheetsConfig | null;
  onSaveConfig: (config: SheetsConfig | null) => void;
  onLogin: () => Promise<void>;
  isLoggingIn: boolean;
}

export const SheetsModal: React.FC<SheetsModalProps> = ({
  isOpen,
  onClose,
  user,
  accessToken,
  sheetsConfig,
  onSaveConfig,
  onLogin,
  isLoggingIn,
}) => {
  const [activeTab, setActiveTab] = useState<'appscript' | 'create' | 'existing'>('appscript');
  const [webAppUrlInput, setWebAppUrlInput] = useState(sheetsConfig?.webAppUrl || '');
  const [customTitle, setCustomTitle] = useState(
    'JUVE JUICE - Rekap Evaluasi & Keluhan Pelanggan (The Taman Dayu)'
  );
  const [existingInput, setExistingInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  // Extract ID if user pastes full URL
  const parseSpreadsheetId = (input: string): string => {
    const trimmed = input.trim();
    const match = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (match && match[1]) {
      return match[1];
    }
    return trimmed;
  };

  const handleSaveAppsScriptUrl = () => {
    const trimmed = webAppUrlInput.trim();
    if (!trimmed.startsWith('https://script.google.com/macros/s/')) {
      setErrorMessage('URL Google Apps Script harus berawalan "https://script.google.com/macros/s/..."');
      return;
    }

    setErrorMessage(null);
    const newConfig: SheetsConfig = {
      spreadsheetId: 'Apps-Script-Web-App',
      spreadsheetUrl: trimmed,
      spreadsheetTitle: 'Google Sheets (via Google Apps Script Web App)',
      webAppUrl: trimmed,
      type: 'apps_script',
      lastSyncedAt: new Date().toISOString(),
    };
    onSaveConfig(newConfig);
    setSuccessMessage('Berhasil menyambungkan Google Apps Script Web App!');
  };

  const handleCreateNewSheet = async () => {
    if (!accessToken) {
      setErrorMessage('Silakan login dengan Google terlebih dahulu.');
      return;
    }

    setLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const result = await createJuveSpreadsheet(accessToken, customTitle);
      const newConfig: SheetsConfig = {
        spreadsheetId: result.spreadsheetId,
        spreadsheetUrl: result.spreadsheetUrl,
        spreadsheetTitle: result.title,
        type: 'oauth',
        lastSyncedAt: new Date().toISOString(),
      };
      onSaveConfig(newConfig);
      setSuccessMessage('Spreadsheet baru berhasil dibuat dan langsung terhubung!');
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Gagal membuat spreadsheet baru.');
    } finally {
      setLoading(false);
    }
  };

  const handleConnectExisting = async () => {
    if (!accessToken) {
      setErrorMessage('Silakan login dengan Google terlebih dahulu.');
      return;
    }

    const sheetId = parseSpreadsheetId(existingInput);
    if (!sheetId) {
      setErrorMessage('Masukkan ID Spreadsheet atau link Google Sheets yang valid.');
      return;
    }

    setLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const verified = await verifySpreadsheet(accessToken, sheetId);
      const newConfig: SheetsConfig = {
        spreadsheetId: sheetId,
        spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`,
        spreadsheetTitle: verified.title,
        type: 'oauth',
        lastSyncedAt: new Date().toISOString(),
      };
      onSaveConfig(newConfig);
      setSuccessMessage(`Berhasil menghubungkan ke spreadsheet "${verified.title}"!`);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(
        err.message || 'Gagal memverifikasi spreadsheet. Pastikan Anda memiliki izin akses.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = () => {
    if (window.confirm('Putuskan koneksi ke Google Spreadsheet saat ini?')) {
      onSaveConfig(null);
      setSuccessMessage('Koneksi spreadsheet telah diputuskan.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-stone-200 overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-5 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-stone-900">
                Integrasi Google Sheets &amp; Apps Script
              </h2>
              <p className="text-xs text-stone-500">
                Penyimpanan otomatis formulir evaluasi &amp; keluhan JUVE JUICE
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Active Configuration Overview */}
          {sheetsConfig && (
            <div className="p-4 rounded-xl bg-emerald-50/80 border border-emerald-200">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800 uppercase tracking-wider">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Spreadsheet / Apps Script Aktif</span>
                  </div>
                  <h3 className="font-bold text-stone-900 text-base">
                    {sheetsConfig.spreadsheetTitle}
                  </h3>
                  <p className="text-xs text-stone-500 font-mono truncate max-w-sm">
                    {sheetsConfig.webAppUrl || `ID: ${sheetsConfig.spreadsheetId}`}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={sheetsConfig.webAppUrl || sheetsConfig.spreadsheetUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-800 bg-white hover:bg-emerald-100 rounded-lg border border-emerald-300 transition-colors shadow-xs"
                  >
                    <span>Buka URL</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <button
                    onClick={handleDisconnect}
                    className="px-2.5 py-1.5 text-xs font-medium text-rose-700 hover:bg-rose-100 rounded-lg transition-colors"
                  >
                    Putuskan
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Mode Tabs */}
          <div className="space-y-4">
            <div className="flex items-center p-1 bg-stone-100 rounded-xl gap-1">
              <button
                type="button"
                onClick={() => setActiveTab('appscript')}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all ${
                  activeTab === 'appscript'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>Apps Script Web App</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('create')}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all ${
                  activeTab === 'create'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <PlusCircle className="w-4 h-4 text-emerald-600" />
                <span>Buat Sheet Baru</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('existing')}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all ${
                  activeTab === 'existing'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <FolderOpen className="w-4 h-4 text-blue-600" />
                <span>OAuth Direct</span>
              </button>
            </div>

            {activeTab === 'appscript' && (
              <div className="space-y-4">
                <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl text-xs space-y-2 text-amber-900">
                  <div className="flex items-center gap-1.5 font-bold text-amber-900">
                    <Info className="w-4 h-4 text-amber-700" />
                    <span>Mengapa Menggunakan Google Apps Script?</span>
                  </div>
                  <p>
                    Metode ini adalah pilihan <strong>terbaik &amp; paling direkomendasikan</strong>.
                    Pelanggan tidak perlu melakukan login Google di HP mereka saat mengirimkan evaluasi/keluhan.
                  </p>
                  <div className="bg-white/80 p-2.5 rounded-lg border border-amber-200 font-mono text-[11px] space-y-1">
                    <p className="font-bold text-amber-800">Langkah Deployment Google Apps Script:</p>
                    <ol className="list-decimal list-inside space-y-1 text-stone-700">
                      <li>Buka file <code className="bg-amber-100 px-1 rounded">google-apps-script.gs</code> di projek ini</li>
                      <li>Salin kodenya ke Apps Script Google Sheet Anda</li>
                      <li>Klik <strong>Deploy &gt; New deployment &gt; Web app</strong></li>
                      <li>Set <em>Execute as</em>: <strong>Me</strong> &amp; <em>Who has access</em>: <strong>Anyone</strong></li>
                      <li>Salin URL Web App dan tempelkan di bawah ini</li>
                    </ol>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-xs font-semibold text-stone-700">
                    URL Google Apps Script Web App
                  </label>
                  <input
                    type="url"
                    value={webAppUrlInput}
                    onChange={(e) => setWebAppUrlInput(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition-all font-mono"
                    placeholder="https://script.google.com/macros/s/AKfycb.../exec"
                  />
                  <button
                    type="button"
                    onClick={handleSaveAppsScriptUrl}
                    disabled={!webAppUrlInput.trim()}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-sm font-semibold shadow-xs transition-colors disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Simpan &amp; Hubungkan Google Apps Script</span>
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'create' && (
              <div className="space-y-3">
                {!user && (
                  <div className="p-3 bg-stone-100 rounded-xl flex items-center justify-between">
                    <span className="text-xs text-stone-600">Butuh login Google OAuth:</span>
                    <button
                      type="button"
                      onClick={onLogin}
                      disabled={isLoggingIn}
                      className="px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-semibold text-stone-700 hover:bg-stone-50"
                    >
                      {isLoggingIn ? 'Memproses...' : 'Masuk Google'}
                    </button>
                  </div>
                )}
                <label className="block text-xs font-semibold text-stone-700">
                  Judul Spreadsheet Baru
                </label>
                <input
                  type="text"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  placeholder="Contoh: JUVE JUICE - Rekap Evaluasi & Keluhan Pelanggan"
                />
                <button
                  type="button"
                  onClick={handleCreateNewSheet}
                  disabled={loading || !customTitle || !user}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold shadow-xs transition-colors disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Sedang Menyiapkan Sheet...</span>
                    </>
                  ) : (
                    <>
                      <PlusCircle className="w-4 h-4" />
                      <span>Buat &amp; Hubungkan Spreadsheet</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {activeTab === 'existing' && (
              <div className="space-y-3">
                {!user && (
                  <div className="p-3 bg-stone-100 rounded-xl flex items-center justify-between">
                    <span className="text-xs text-stone-600">Butuh login Google OAuth:</span>
                    <button
                      type="button"
                      onClick={onLogin}
                      disabled={isLoggingIn}
                      className="px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-semibold text-stone-700 hover:bg-stone-50"
                    >
                      {isLoggingIn ? 'Memproses...' : 'Masuk Google'}
                    </button>
                  </div>
                )}
                <label className="block text-xs font-semibold text-stone-700">
                  Link atau ID Spreadsheet Google Sheets
                </label>
                <input
                  type="text"
                  value={existingInput}
                  onChange={(e) => setExistingInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  placeholder="https://docs.google.com/spreadsheets/d/1aBcD.../edit atau ID sheet"
                />
                <button
                  type="button"
                  onClick={handleConnectExisting}
                  disabled={loading || !existingInput.trim() || !user}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold shadow-xs transition-colors disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Memverifikasi Akses...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Hubungkan Spreadsheet Ini</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>

          {/* Feedback messages */}
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs font-medium text-rose-800">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs font-medium text-emerald-800">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successMessage}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-stone-50 border-t border-stone-100 flex items-center justify-between">
          <p className="text-[11px] text-stone-500">
            JUVE JUICE Evaluasi &amp; Keluhan Layanan Stand Taman Dayu.
          </p>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-700 hover:text-stone-900 bg-white hover:bg-stone-100 border border-stone-200 rounded-lg transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};

