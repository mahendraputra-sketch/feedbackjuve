# JUVE JUICE - Evaluasi & Keluhan Pelanggan (New Food Terrace Taman Dayu)

Aplikasi web modern untuk pengumpulan evaluasi kepuasan pelanggan, penanganan keluhan, dan integrasi Google Sheets & Google Apps Script.

---

## 🛠️ Panduan Fix & Deploy ke Vercel

### 1. File & Konfigurasi Vercel yang Disediakan
- **`package.json`**: Versi dependensi telah diperbaiki dengan npm semver standar (`typescript ^5.7.3`, `vite ^6.2.0`, `@vitejs/plugin-react ^4.3.4`, dll) agar `npm install` di Vercel tidak error.
- **`vercel.json`**: Menangani routing SPA (Single Page Application) agar halaman tidak 404 saat direfresh di Vercel.

### 2. Cara Deploy ke Vercel:
1. Push repositori ini ke **GitHub**.
2. Buka [Vercel Dashboard](https://vercel.com/new).
3. Import repositori GitHub ini.
4. Pastikan **Framework Preset** terdeteksi sebagai **Vite**.
5. Klik tombol **Deploy**.

---

## 📝 Panduan Setup Google Apps Script (Webhook Sheets)

Aplikasi ini dilengkapi file `google-apps-script.gs` yang siap dipakai agar pelanggan dapat mengirim masukan ke Google Sheets **tanpa perlu login Google di HP mereka**.

### Langkah-langkah di Google Sheets:
1. Buat Google Sheet baru di Google Drive Anda.
2. Klik **Ekstensi (Extensions)** -> **Apps Script**.
3. Hapus semua kode bawaan, lalu **salin (copy) & tempel (paste)** seluruh isi file `google-apps-script.gs`.
4. Klik **Simpan** (ikon disket).
5. Klik **Deploy (Terapkan)** -> **New deployment (Terapkan sebagai Aplikasi Web)**.
6. Konfigurasi:
   - **Select type**: Web App (Aplikasi Web)
   - **Execute as (Jalankan sebagai)**: `Me (Saya)`
   - **Who has access (Yang memiliki akses)**: `Anyone (Siapa saja)` ⚠️ *Penting agar kiriman dari HP pelanggan diterima!*
7. Klik **Deploy**, beri izin akses (Authorize Access) akun Google Anda.
8. Salin **Web App URL** (berawalan `https://script.google.com/macros/s/.../exec`).
9. Di aplikasi web JUVE JUICE (atau modal pengelola), klik ikon **Google Sheets**, masuk ke tab **Apps Script Web App**, lalu tempelkan URL tersebut dan simpan.

---

## 💻 Jalankan Lokal (Development)

1. `npm install`
2. `npm run dev`
3. Buka di browser: `http://localhost:3000`
