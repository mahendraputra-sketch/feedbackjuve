/**
 * ==============================================================================
 * GOOGLE APPS SCRIPT - SINKRONISASI EVALUASI & KELUAHAN JUVE JUICE
 * Stand: New Food Terrace The Taman Dayu
 * ==============================================================================
 * 
 * PETUNJUK PEMAKAIAN & DEPLOYMENT DI GOOGLE APPS SCRIPT:
 * 1. Buka Google Sheets Anda (atau buat sheet baru di Google Drive).
 * 2. Klik menu "Ekstensi" (Extensions) -> "Apps Script".
 * 3. Hapus semua kode default, lalu salin dan tempel (copy-paste) seluruh isi file ini.
 * 4. Klik tombol "Simpan" (ikon disket).
 * 5. Klik tombol "Terapkan" (Deploy) di sudut kanan atas -> pilih "Terapkan sebagai Aplikasi Web" (New deployment -> Web app).
 * 6. Atur konfigurasi sebagai berikut:
 *    - Deskripsi: Integrasi Form Feedback JUVE JUICE
 *    - Jalankan sebagai (Execute as): "Saya" (Me / email anda)
 *    - Yang memiliki akses (Who has access): "Siapa saja" (Anyone) -> PERBAIKAN PENTING!
 * 7. Klik "Terapkan" (Deploy), lalu izinkan akses (Authorize Access) akun Google Anda.
 * 8. Salin URL Web App yang dihasilkan (berawalan https://script.google.com/macros/s/...)
 * 9. Tempelkan URL tersebut ke konfigurasi di aplikasi React JUVE JUICE Anda!
 * ==============================================================================
 */

// Nama Sheet tempat data akan disimpan
var SHEET_NAME = "Penilaian & Keluhan";

// Header Kolom Baku
var HEADERS = [
  "ID Evaluasi",
  "Waktu Pengisian",
  "Nama Pelanggan",
  "No. WhatsApp",
  "No. Meja / Order",
  "Kategori Menu",
  "Menu Dipesan",
  "Pegawai / Shift Melayani",
  "Rating Layanan (1-5)",
  "Keluhan / Masukan Pelanggan",
  "Ada Foto Bukti?",
  "Status Penanganan",
  "Catatan Internal Stand"
];

/**
 * Memproses permintaan POST dari formulir website (CustomerForm)
 */
function doPost(e) {
  try {
    var data = {};
    
    // Parse data JSON yang dikirim oleh website
    if (e && e.postData && e.postData.contents) {
      try {
        data = JSON.parse(e.postData.contents);
      } catch (jsonErr) {
        // Fallback jika dikirim via URL encoded form data
        data = e.parameter || {};
      }
    } else if (e && e.parameter) {
      data = e.parameter;
    }

    // Ambil spreadsheet aktif tempat script ini dipasang
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) {
      return createJsonResponse({
        status: "error",
        message: "Spreadsheet tidak ditemukan. Pastikan script dipasang di Google Sheets (Ekstensi -> Apps Script)."
      });
    }

    var sheet = ss.getSheetByName(SHEET_NAME);
    
    // Jika sheet belum ada, buat sheet baru dan isi header
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow(HEADERS);
      formatHeaderRow(sheet);
    } else {
      // Jika baris pertama kosong, tambahkan header
      if (sheet.getLastRow() === 0) {
        sheet.appendRow(HEADERS);
        formatHeaderRow(sheet);
      }
    }

    // Olah nilai tanggal & waktu WIB
    var formattedDate = data.createdAt 
      ? Utilities.formatDate(new Date(data.createdAt), "Asia/Jakarta", "dd/MM/yyyy HH:mm:ss")
      : Utilities.formatDate(new Date(), "Asia/Jakarta", "dd/MM/yyyy HH:mm:ss");

    // Susun baris data baru sesuai urutan header
    var rowValues = [
      data.id || ("JJ-" + new Date().getFullYear() + "-" + Math.floor(1000 + Math.random() * 9000)),
      formattedDate,
      data.customerName || "Pelanggan (Anonim)",
      data.customerPhone || "-",
      data.tableOrOrderNo || "-",
      data.menuCategory || "Jus Buah",
      data.menuItem || "-",
      data.staffNameOrShift || "-",
      Number(data.rating) || 5,
      data.complaintOrFeedback || "-",
      data.photoUrl ? "Ada Foto (Terlampir)" : "Tidak Ada",
      (data.status || "BARU").toUpperCase(),
      data.internalNotes || "-"
    ];

    // Tambahkan baris baru ke sheet
    sheet.appendRow(rowValues);

    // Berikan balasan JSON yang valid dengan header CORS
    return createJsonResponse({
      status: "success",
      message: "Masukan/evaluasi berhasil disimpan ke Google Sheets JUVE JUICE!",
      id: rowValues[0]
    });

  } catch (error) {
    return createJsonResponse({
      status: "error",
      message: "Terjadi kesalahan pada Apps Script: " + error.toString()
    });
  }
}

/**
 * Memproses permintaan GET untuk cek status koneksi dari website
 */
function doGet(e) {
  return createJsonResponse({
    status: "online",
    service: "JUVE JUICE Feedback Webhook API",
    time: new Date().toISOString()
  });
}

/**
 * Helper untuk memberikan Format Header yang rapi di Google Sheets
 */
function formatHeaderRow(sheet) {
  var headerRange = sheet.getRange(1, 1, 1, HEADERS.length);
  headerRange.setBackground("#059669"); // Emerald 600
  headerRange.setFontColor("#FFFFFF");
  headerRange.setFontWeight("bold");
  headerRange.setHorizontalAlignment("center");
  sheet.setFrozenRows(1);
}

/**
 * Helper untuk membuat response JSON dengan penanganan CORS
 */
function createJsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
